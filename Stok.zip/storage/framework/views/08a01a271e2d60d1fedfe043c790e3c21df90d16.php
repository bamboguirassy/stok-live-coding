<?php $__env->startComponent('mail::message'); ?>
# Stok

<?php echo $mail['message']; ?>


Merci,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\wamp64\www\live-coding\Stok\resources\views/emails/email-to-responsable.blade.php ENDPATH**/ ?>