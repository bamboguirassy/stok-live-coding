<?php $__env->startSection('content'); ?>
<section data-bs-version="5.1" class="header8 cid-sP8n1S8d3Q" id="header8-2">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12">
                <h3 class="mbr-section-title mbr-white mbr-fonts-style display-1">
                    <strong>Bambo Inc.</strong>
                </h3>
                <p class="mbr-text mbr-fonts-style mbr-white mb-4 display-1">Create your own website.<br><a
                        href="index.html#formbuilder-6" class="text-danger text-primary"><strong>Ouvrir une filiale
                            &gt;&gt;</strong></a></p>
            </div>
        </div>
    </div>
</section>

<?php if (isset($component)) { $__componentOriginal3c8a21f9f971e74a163d4cab718f6e0ac6cd33a0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\FilialeList::class, ['filiales' => $filiales]); ?>
<?php $component->withName('filiale-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c8a21f9f971e74a163d4cab718f6e0ac6cd33a0)): ?>
<?php $component = $__componentOriginal3c8a21f9f971e74a163d4cab718f6e0ac6cd33a0; ?>
<?php unset($__componentOriginal3c8a21f9f971e74a163d4cab718f6e0ac6cd33a0); ?>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginal250e53d04651acb9085e329df750df72fb6b1018 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\FilialeNew::class, []); ?>
<?php $component->withName('filiale-new'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal250e53d04651acb9085e329df750df72fb6b1018)): ?>
<?php $component = $__componentOriginal250e53d04651acb9085e329df750df72fb6b1018; ?>
<?php unset($__componentOriginal250e53d04651acb9085e329df750df72fb6b1018); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\live-coding\Stok\resources\views/home.blade.php ENDPATH**/ ?>