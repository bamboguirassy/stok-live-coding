<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Produit extends Model
{
    use HasFactory;

    protected $fillable = [
        'nom',
        'quantite',
        'prixUntaire',
        'filiale_id'
    ];

    public function getDisponibleAttribute() {
        return $this->quantite>25;
    }
}
